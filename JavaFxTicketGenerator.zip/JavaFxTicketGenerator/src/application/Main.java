package application;
	
import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;


public class Main extends Application {
	@Override
	public void start(Stage primaryStage) {
		try {
			AnchorPane root = (AnchorPane) FXMLLoader.load(getClass().getResource("/application/mainwindows.fxml"));
	        primaryStage.setTitle("Ticket generator 2.1.1");
	        primaryStage.getIcons().add(new Image(getClass().getResourceAsStream("/application/icon.png")));
	        primaryStage.setScene(new Scene(root, 800, 420));
	        primaryStage.setResizable(true);
	        primaryStage.show();
	        
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
	
	
}
